export class artInfo
{
  pname: string;
  ptype: string;
  artist: string;
  pic: string;
  pyear: string;
}