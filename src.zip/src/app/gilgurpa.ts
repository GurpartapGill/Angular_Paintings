export class Gilgurpa
{
  sid: string;
  sname: string;
  slogin: string;
  scampus: string;
  atitle: string;
}